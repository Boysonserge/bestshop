<div class="grid gap-6 mb-8 lg:grid-cols-2 xl:grid-cols-4">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/components/jet-bar-stats-container.blade.php ENDPATH**/ ?>