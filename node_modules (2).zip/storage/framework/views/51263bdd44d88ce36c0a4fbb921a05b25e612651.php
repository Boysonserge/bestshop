
    
<tr class="bg-white border-b hover:bg-gray-50">
    <td>

    <td class="px-6 py-4 font-medium whitespace-nowrap">
        
        <button wire:click="" class="bg-blue-700 text-white p-2 rounded-full">Remove</button>
    </td>
    </td>
    <td class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">
        <img class="w-8" src="<?php echo e(\App\Models\Product::find(2)->productImage); ?>" alt="">
    </td>
        <td class="px-6 py-4 font-medium whitespace-nowrap"><?php echo e($productName); ?></td>
        <td class="px-6 py-4 font-medium whitespace-nowrap">42</td>
    <td class="px-6 py-4 font-medium whitespace-nowrap">43</td>
    <td class="px-6 py-4 font-medium whitespace-nowrap">23</td>
    <td class="px-6 py-4 font-medium whitespace-nowrap">42</td>
    <td class="px-6 py-4 font-medium whitespace-nowrap">43</td>
</tr>


<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/livewire/cart-row.blade.php ENDPATH**/ ?>