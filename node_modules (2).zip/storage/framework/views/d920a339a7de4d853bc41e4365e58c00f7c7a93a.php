    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
                <th></th>
                <th scope="col" class="px-6 py-3">
                    Delete
                </th>
                <th scope="col" class="px-6 py-3">
                    Image
                </th>
                <th scope="col" class="px-6 py-3">
                    Product name
                </th>
                <th scope="col" class="px-6 py-3">
                    Price (RWF)
                </th>
                <th scope="col" class="px-6 py-3">
                    Subtotal (RWF)
                </th>
                <th scope="col" class="px-6 py-3">
                    Quantity
                </th>
            </tr>
            </thead>
            <tbody>
            
            
            
            
            
            
            
            <?php if(count($cartItems)>0): ?>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white border-b hover:bg-gray-50">
                        <td>
                            <?php echo e($rowId); ?>

                        </td>
                        <td class="px-6 py-4 font-medium whitespace-nowrap">
                            
                            <button wire:click="deleteCart('<?php echo e($carts->rowId); ?>')" class="bg-blue-700 text-white p-2 rounded-full">Remove</button>
                        </td>
                        <td class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">
                            <img class="w-8" src="<?php echo e(\App\Models\Product::find($carts->id)->productImage); ?>" alt="">
                        </td>
                        <td class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">
                            <?php echo e($carts->name); ?>


                        </td>
                        <td class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">
                            <?php echo e(number_format($carts->price)); ?>

                            <?php echo e($price); ?>

                        </td>

                        <td class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">
                            <?php echo e(number_format($carts->total)); ?>

                        </td>
                        <td class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">

                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-cart', ['myCarts' => $carts])->html();
} elseif ($_instance->childHasBeenRendered($carts->id)) {
    $componentId = $_instance->getRenderedChildComponentId($carts->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($carts->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($carts->id);
} else {
    $response = \Livewire\Livewire::mount('update-cart', ['myCarts' => $carts]);
    $html = $response->html();
    $_instance->logRenderedChild($carts->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-gray-100 text-gray-800">
                    <th class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap" colspan="4">TOTAL</th>
                    <th class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">
                        <?php echo e($total); ?>

                    </th>
                    <th colspan="2" class="px-6 py-4 font-medium text-gray-900  whitespace-nowrap">
                        <button wire:click.prevent="proceed()"
                                type="button"
                                class="w-full px-3 py-2 text-xs font-medium text-center text-white bg-blue-700
                                rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300
                                dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Proceed to checkout</button>

                    </th>
                </tr>
            <?php else: ?>
                <th class="text-center" colspan="6"><span
                        class="text-center text-red-500">They are no items in a cart</span></th>
            <?php endif; ?>

            </tbody>
        </table>


    </div>

<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/livewire/cart-items.blade.php ENDPATH**/ ?>