<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-details', [])->html();
} elseif ($_instance->childHasBeenRendered('6Y1tUdU')) {
    $componentId = $_instance->getRenderedChildComponentId('6Y1tUdU');
    $componentTag = $_instance->getRenderedChildComponentTagName('6Y1tUdU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6Y1tUdU');
} else {
    $response = \Livewire\Livewire::mount('product-details', []);
    $html = $response->html();
    $_instance->logRenderedChild('6Y1tUdU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/detailsTest.blade.php ENDPATH**/ ?>