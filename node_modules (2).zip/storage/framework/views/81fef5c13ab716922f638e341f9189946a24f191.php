<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/detail.css')); ?>">
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php echo \Livewire\Livewire::styles(); ?>

<head><title>Items in cart</title></head>
<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<div class="overlay" data-overlay></div>

<main>
    <div class="bg-yellow-50 py-12 px-6 flex justify-center mb-6">
        <div class="text-yellow-500 py-12 px-6 text-center">
            <h1 class="text-2xl font-extrabold"> Products in a cart</h1>
            <hr>
        </div>
    </div>
    <div class="container mb-6">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-items')->html();
} elseif ($_instance->childHasBeenRendered('hUwzToM')) {
    $componentId = $_instance->getRenderedChildComponentId('hUwzToM');
    $componentTag = $_instance->getRenderedChildComponentTagName('hUwzToM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hUwzToM');
} else {
    $response = \Livewire\Livewire::mount('cart-items');
    $html = $response->html();
    $_instance->logRenderedChild('hUwzToM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</main>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

<!--
- ionicon link
-->

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script  nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>


</html>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/cartItems.blade.php ENDPATH**/ ?>