<div class="header-search-container">
    <form action="<?php echo e(route('search')); ?>" method="POST" autocomplete="off">
        <?php echo csrf_field(); ?>
        <input wire:model="searchKey" required type="search" name="searchQuery" class="search-field" placeholder="Enter your product name...">
        <button type="submit" class="search-btn">
            <ion-icon name="search-outline"></ion-icon>
        </button>
    </form>
    <?php if($searchKey): ?>
        <ul class="absolute z-10 w-48 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
            <?php $__currentLoopData = $searchResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="w-full px-4 py-2 border-b border-gray-200 dark:border-gray-600">
                    <a href="<?php echo e(route('prodDetails', ['id' => $sear->productSlug])); ?>"><?php echo e($sear->productName); ?></a>
                </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/livewire/search.blade.php ENDPATH**/ ?>