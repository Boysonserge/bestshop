<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/components/jet-bar-table-data.blade.php ENDPATH**/ ?>