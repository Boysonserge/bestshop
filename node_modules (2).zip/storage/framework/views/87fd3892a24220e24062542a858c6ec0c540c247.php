<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Dashboard')); ?>

     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dash-cards')->html();
} elseif ($_instance->childHasBeenRendered('gqIh3f6')) {
    $componentId = $_instance->getRenderedChildComponentId('gqIh3f6');
    $componentTag = $_instance->getRenderedChildComponentTagName('gqIh3f6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gqIh3f6');
} else {
    $response = \Livewire\Livewire::mount('dash-cards');
    $html = $response->html();
    $_instance->logRenderedChild('gqIh3f6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/dashboard.blade.php ENDPATH**/ ?>