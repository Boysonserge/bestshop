<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo e(asset('images/logo/favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('css/style-prefix.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/flowbite.css')); ?>">


    <style>
        ion-icon {
            --ionicon-stroke-width: 32px;
        }

        img {
            width: 100%;
            display: block;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/flowbite.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style-prefix.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/flowbite.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>


    <title>search results for: "<?php echo e($query); ?>" | Bestshop Rwanda</title>


</head>

<body>
<div class="overlay" data-overlay></div>
<?php echo $__env->make('inc/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="bg-yellow-50 py-12 px-6 flex justify-center mb-6">
    <div class="text-yellow-500 py-12 px-6 text-center">
        <h3>search results for:</h3>
        <h1 class="text-2xl font-extrabold"> "<?php echo e($query); ?>"></h1>
        <hr>
    </div>
</div>
<!-- Modal toggle -->

<div class="container">
    <div class="product-main">

        <h2 class="title">Products in this category</h2>

        <?php if(count($search)>0): ?>
            <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-grid">
                    <div class="showcase">
                        <div class="showcase-banner">
                            <img src="<?php echo e($pro->productImage); ?>" alt=" " class="product-img default w-5">
                            <a href="<?php echo e(route('prodDetails', ['id' => $pro->productSlug])); ?>">
                                <img src="<?php echo e(asset($pro->productImage)); ?>" alt="Coffe machine" width="300"
                                     class="product-img hover"></a>
                            <p class="showcase-badge">15%</p>
                            <div class="showcase-actions">
                                <button class="btn-action">
                                    <ion-icon name="cart"></ion-icon>
                                </button>
                            </div>
                        </div>
                        <div class="showcase-content">
                            <a href="#" class="showcase-category">.. </a>
                            <a href="<?php echo e(route('prodDetails', ['id' => $pro->productSlug])); ?>">
                                <h3 class="showcase-title"><?php echo e($pro->productName); ?></h3>
                            </a>
                            <div class="showcase-rating">
                                <ion-icon name="star"></ion-icon>
                                <ion-icon name="star"></ion-icon>
                                <ion-icon name="star"></ion-icon>
                                <ion-icon name="star-outline"></ion-icon>
                                <ion-icon name="star-outline"></ion-icon>
                            </div>
                            <div class="price-box">
                                <p class="price"><?php echo e(number_format($pro->productPrice)); ?> rwf</p>
                                <del><?php echo e(number_format(($pro->productPrice)+500)); ?> rwf</del>
                            </div>
                            <form wire:submit.prevent="addCart(<?php echo e($pro->id); ?>)">

                                <input wire:model.lazy="cartQuantity" min="1" type="number" name="quantity" id="quantity"
                                       class="bg-gray-50 border border-gray-300 text-gray-900
                            text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                            mb-4" placeholder="quantity" required>

                                <?php
                                $cart = Gloudemans\Shoppingcart\Facades\Cart::content()?>
                                <?php if($cart->where('id',$pro->id)->count()): ?>
                                    <button disabled class="bg-blue-100 px-6 w-full rounded-full mb-4">Added to cart</button>
                                <?php else: ?>
                                    <button
                                        type="submit" class="mb-6 w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4
                            focus:outline-none  font-medium rounded-lg text-sm sm:w-auto
                            px-5 py-2.5 text-center ">
                                        Add to cart <br><small>(Hitamo igicuruzwa)</small></button>

                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            No products available for such query
        <?php endif; ?>





        <?php echo e($search->links()); ?>


    </div>
</div>



<?php echo $__env->make('inc/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/detail.js')); ?>"></script>
<script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/flowbite.js')); ?>"></script>

<!--
- ionicon link
-->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

<?php echo \Livewire\Livewire::scripts(); ?>

</body>


</html>

<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/search.blade.php ENDPATH**/ ?>