<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-sans text-xl text-indigo-700">
            <?php echo e(__('My products')); ?>

        </h2>





     <?php $__env->endSlot(); ?>

    <div class="py-12 overflow-x-auto   ">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 overflow-x-auto ">
            <?php if(session()->has('message')): ?>
                <h2 class="font-sans text-xl text-indigo-700">
                    <?php echo e(session('message')); ?>

                </h2>
            <?php endif; ?>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('products')->html();
} elseif ($_instance->childHasBeenRendered('vcamSa9')) {
    $componentId = $_instance->getRenderedChildComponentId('vcamSa9');
    $componentTag = $_instance->getRenderedChildComponentTagName('vcamSa9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vcamSa9');
} else {
    $response = \Livewire\Livewire::mount('products');
    $html = $response->html();
    $_instance->logRenderedChild('vcamSa9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        </div>
    </div>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/admin/products.blade.php ENDPATH**/ ?>