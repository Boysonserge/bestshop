<div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/components/jet-bar-container.blade.php ENDPATH**/ ?>