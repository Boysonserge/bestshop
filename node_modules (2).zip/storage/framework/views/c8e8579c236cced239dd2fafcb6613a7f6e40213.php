<div>
    <input type="text" wire:model="number"><br>


    <?php if($number==1): ?>
        <input wire:click.prevent="change" type="submit" value="Change me"
               class="bg-blue-600 text-white p-3 cursor-pointer">

    <?php else: ?>
        <input wire:click.prevent="change2" type="submit" value="Change me too"
               class="bg-red-600 text-red-500 p-3 cursor-pointer">

    <?php endif; ?>



    <?php if(session()->has('message')): ?>
        <label for="id" class="text-blue-600 bg-gray-100"><?php echo e(session('message')); ?></label>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/livewire/test.blade.php ENDPATH**/ ?>