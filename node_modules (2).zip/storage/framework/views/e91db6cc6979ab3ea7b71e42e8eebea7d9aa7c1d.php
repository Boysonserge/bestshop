<div class="flex space-x-4">
    <input class="border-blue-300 w-32" wire:model="quantity" type="number" min="1">
    <button wire:click.prevent="updateCart()" type="button" class="px-3 py-2 text-xs font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Update</button>
</div>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/livewire/update-cart.blade.php ENDPATH**/ ?>