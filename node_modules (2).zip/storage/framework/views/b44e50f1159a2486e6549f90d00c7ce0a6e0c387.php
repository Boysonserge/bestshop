<div>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="sidebar-menu-category">

            <button class="sidebar-accordion-menu" data-accordion-btn>

                <div class="menu-title-flex">
                    <img src="<?php echo e($cats->category_icon); ?>" alt="clothes" width="20"
                         height="20" class="menu-title-img">

                    <p class="menu-title">
                        <a href="<?php echo e(route('category', ['category_slug' => $cats->category_slug])); ?>">
                            <?php echo e($cats->productCategory); ?></a>
                    </p>
                </div>

                <div>
                    <ion-icon name="add-outline" class="add-icon"></ion-icon>
                    <ion-icon name="remove-outline" class="remove-icon"></ion-icon>
                </div>

            </button>

            <ul class="sidebar-submenu-category-list" data-accordion>


                <li class="sidebar-submenu-category">
                    <?php $__currentLoopData = $cats->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#" class="sidebar-submenu-title">
                            <p class="product-name"><?php echo e($pr->productName); ?></p>
                            <data value="87" class="stock font-extrabold"
                                  title="Available Stock"><?php echo e(number_format($pr->productPrice)); ?>

                                Rfw
                            </data>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>

            </ul>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/livewire/categories.blade.php ENDPATH**/ ?>