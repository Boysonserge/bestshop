<header>
    <?php
    $cats = \App\Models\Category::with('products')->take(5)->get();

    ?>
    <div class="header-top">

        <div class="container">

            <ul class="header-social-container">

                <li>
                    <a target="__blank" href="https://www.instagram.com/best_shop_ltd/" class="social-link">
                        <ion-icon name="logo-instagram"></ion-icon>
                    </a>
                </li>
                <li>
                    <a href="#" class="social-link">
                        <ion-icon name="logo-facebook"></ion-icon>
                    </a>
                </li>

                <li>
                    <a href="#" class="social-link">
                        <ion-icon name="logo-twitter"></ion-icon>
                    </a>
                </li>

            </ul>

            <div class="header-alert-news">
                <p>
                    <b>GET YOUR PRODUCT DELIVERED</b>
                    As soon as possible
                </p>
            </div>

            

        </div>

    </div>

    <div class="header-main">

        <div class="container">

            <a href="<?php echo e(route('home')); ?>" class="header-logo">
                <img style="width: 40%;display: block;" src="<?php echo e(asset('images/logo/logo-01.png')); ?>"
                     alt="Best shop logo" width="150" height="76">
            </a>



                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('ux6sqmK')) {
    $componentId = $_instance->getRenderedChildComponentId('ux6sqmK');
    $componentTag = $_instance->getRenderedChildComponentTagName('ux6sqmK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ux6sqmK');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('ux6sqmK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


            <div class="header-user-actions">
                <button class="action-btn">
                    <a href="<?php echo e(route('client/dashboard')); ?>">
                        <ion-icon name="person-circle"></ion-icon>
                    </a>

                </button>
                <a href="<?php echo e(route('cart.fetch')); ?>" class="action-btn">
                    <ion-icon name="cart"></ion-icon>
                    <span class="count"><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::content()->count()); ?></span>
                </a>

            </div>

        </div>

    </div>

    <nav class="desktop-navigation-menu">

        <div class="container">

            <ul class="desktop-menu-category-list">

                <li class="menu-category">
                    <a href="<?php echo e(route('home')); ?>" class="menu-title">Home</a>

                </li>

                <li class="menu-category">
                    <a href="" class="menu-title">Top products</a>
                </li>

                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="menu-category">
                        <a href="#" class="menu-title"><?php echo e($cate->productCategory); ?></a>
                        <?php if(count($cate->products)): ?>
                            <ul class="dropdown-list">
                                <?php $__currentLoopData = $cate->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(route('prodDetails', ['id' => $prods->productSlug])); ?>"><?php echo e($prods->productName); ?> </a>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        <?php endif; ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <li class="menu-category">
                    <a href="#" class="menu-title">Contact</a>
                </li>

                <li class="menu-category">
                    <a href="#" class="menu-title">Hot Offers</a>
                </li>

            </ul>

        </div>

    </nav>

    <div class="mobile-bottom-navigation">

        <button class="action-btn" data-mobile-menu-open-btn>
            <ion-icon name="menu-outline"></ion-icon>
        </button>

        <a href="<?php echo e(route('cart.fetch')); ?>" class="action-btn">
            <ion-icon name="cart"></ion-icon>
            <span class="count"><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::content()->count()); ?></span>
        </a>

        <button class="action-btn">
            <ion-icon name="home-outline"></ion-icon>
        </button>


        <button class="action-btn" data-mobile-menu-open-btn>
            <ion-icon name="grid-outline"></ion-icon>
        </button>

    </div>

    <nav class="mobile-navigation-menu  has-scrollbar" data-mobile-menu>

        <div class="menu-top">
            <h2 class="menu-title">Menu</h2>

            <button class="menu-close-btn" data-mobile-menu-close-btn>
                <ion-icon name="close-outline"></ion-icon>
            </button>
        </div>

        <ul class="mobile-menu-category-list">

            <li class="menu-category">
                <a href="#" class="menu-title">Home</a>
            </li>
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="menu-category">

                        <button class="accordion-menu" data-accordion-btn>
                            <p class="menu-title"><?php echo e($cate->productCategory); ?></p>
                            <div>
                                <ion-icon name="add-outline" class="add-icon"></ion-icon>
                                <ion-icon name="remove-outline" class="remove-icon"></ion-icon>
                            </div>
                        </button>

                        <?php if(count($cate->products)): ?>

                            <ul class="submenu-category-list" data-accordion>
                                <?php $__currentLoopData = $cate->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li class="submenu-category">
                                        <a href="<?php echo e(route('prodDetails', ['id' => $prods->productSlug])); ?>"
                                           class="submenu-title"><?php echo e($prods->productName); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li class="menu-category">

                    <button class="accordion-menu" data-accordion-btn>
                        <p class="menu-title">Coffee materials</p>

                        <div>
                            <ion-icon name="add-outline" class="add-icon"></ion-icon>
                            <ion-icon name="remove-outline" class="remove-icon"></ion-icon>
                        </div>
                    </button>

                    <ul class="submenu-category-list" data-accordion>
                        <li class="submenu-category">
                            <a href="#" class="submenu-title">View all</a>
                        </li>
                    </ul>
                </li>

                <li class="menu-category">

                    <button class="accordion-menu" data-accordion-btn>
                        <p class="menu-title">Butchery
                        </p>

                        <div>
                            <ion-icon name="add-outline" class="add-icon"></ion-icon>
                            <ion-icon name="remove-outline" class="remove-icon"></ion-icon>
                        </div>
                    </button>

                    <ul class="submenu-category-list" data-accordion>

                        <li class="submenu-category">
                            <a href="#" class="submenu-title">View all</a>
                        </li>

                    </ul>

                </li>

                <li class="menu-category">

                    <button class="accordion-menu" data-accordion-btn>
                        <p class="menu-title">Bakery
                        </p>

                        <div>
                            <ion-icon name="add-outline" class="add-icon"></ion-icon>
                            <ion-icon name="remove-outline" class="remove-icon"></ion-icon>
                        </div>
                    </button>

                    <ul class="submenu-category-list" data-accordion>

                        <li class="submenu-category">
                            <a href="#" class="submenu-title">View all</a>
                        </li>
                    </ul>
                </li>

        </ul>

        <div class="menu-bottom">
            <ul class="menu-social-container">
                <li>
                    <a href="#" class="social-link">
                        <ion-icon name="logo-facebook"></ion-icon>
                    </a>
                </li>

                <li>
                    <a href="#" class="social-link">
                        <ion-icon name="logo-twitter"></ion-icon>
                    </a>
                </li>

                <li>
                    <a href="#" class="social-link">
                        <ion-icon name="logo-instagram"></ion-icon>
                    </a>
                </li>

                <li>
                    <a href="#" class="social-link">
                        <ion-icon name="logo-linkedin"></ion-icon>
                    </a>
                </li>

            </ul>

        </div>

    </nav>

</header>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/inc/header.blade.php ENDPATH**/ ?>