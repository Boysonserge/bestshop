<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/detail.css')); ?>">
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">

<link rel="stylesheet" href="<?php echo e(asset('css/flowbite.css')); ?>">

<?php echo \Livewire\Livewire::styles(); ?>

<head><title>Items in cart</title></head>
<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<div class="overlay" data-overlay></div>

<main>
    <div class="bg-yellow-50 py-12 px-6 flex justify-center mb-6">
        <div class="text-yellow-500 py-12 px-6 text-center">
            <h1 class="text-2xl font-extrabold"> Products in a cart</h1>
            <hr>
        </div>
    </div>

    <div class="container mb-6">
        <div class="grid sm:grid-cols-1 md:grid-cols-2 gap-4 items-end">
            <div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login-side')->html();
} elseif ($_instance->childHasBeenRendered('ww18Vb3')) {
    $componentId = $_instance->getRenderedChildComponentId('ww18Vb3');
    $componentTag = $_instance->getRenderedChildComponentTagName('ww18Vb3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ww18Vb3');
} else {
    $response = \Livewire\Livewire::mount('login-side');
    $html = $response->html();
    $_instance->logRenderedChild('ww18Vb3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('register-side')->html();
} elseif ($_instance->childHasBeenRendered('7t8FcOJ')) {
    $componentId = $_instance->getRenderedChildComponentId('7t8FcOJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('7t8FcOJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7t8FcOJ');
} else {
    $response = \Livewire\Livewire::mount('register-side');
    $html = $response->html();
    $_instance->logRenderedChild('7t8FcOJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<!--
- ionicon link
-->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="<?php echo e(asset('js/flowbite.js')); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>


</html>
<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/user-login.blade.php ENDPATH**/ ?>