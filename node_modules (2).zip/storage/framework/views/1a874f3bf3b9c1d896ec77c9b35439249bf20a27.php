<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo e(asset('images/logo/favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('css/style-prefix.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/flowbite.css')); ?>">


    <style>
        ion-icon {
            --ionicon-stroke-width: 32px;
        }

        img {
            width: 100%;
            display: block;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/detail.css')); ?>">

    <?php echo e(die()); ?>

    <title><?php echo e($myProds->productName); ?> | Bestshop Rwanda</title>



</head>

<body>
<div class="overlay" data-overlay></div>
<?php echo $__env->make('inc/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="bg-yellow-50 py-12 px-6 flex justify-center mb-6">
    <div class="text-yellow-500 py-12 px-6 text-center">
        <h3>Buying portal for:</h3>
        <h1 class="text-2xl font-extrabold"> <?php echo e($myProds->productName); ?></h1>
        <hr>
    </div>
</div>




<div class="card">
    <!-- left -->
    <div class="product-imgs">
        <div class="img-display">
            <div class="img-showcase w-3">
                <img src="<?php echo e(asset($myProds->productImage)); ?>" alt="">
                <?php $__currentLoopData = $openedOther; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <img class="" src="<?php echo e(asset($other->imagePath)); ?>" alt="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>

        <div class="img-select">

            <div class="img-item">
                <a href="#" data-id='1'>
                    <img src="<?php echo e(asset($myProds->productImage)); ?>" alt="">
                </a>
            </div>
            <?php $__currentLoopData = $openedOther; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other=>$key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="img-item">
                    <a href="#" data-id="<?php echo e($other+2); ?>">

                        <img src="<?php echo e(asset($key->imagePath)); ?>" alt="">
                    </a>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <!-- Right -->
    <div class="product-content">

        <p class="text-3xl uppercase font-extrabold dark:text-white"><?php echo e($myProds->productName); ?></p>
        <div class="product-rating">
            <ion-icon name="star"></ion-icon>
            <ion-icon name="star"></ion-icon>
            <ion-icon name="star"></ion-icon>
            <ion-icon name="star"></ion-icon>
            <ion-icon name="star"></ion-icon>
            <ion-icon name="star"></ion-icon>
            <ion-icon name="star-half-outline"></ion-icon>
            <span>4.7(12)</span>
        </div>

        <div class="product-price">
            <p class="last-price">Old price: <span><?php echo e($myProds->productPrice+500); ?> RWF</span></p>
            <p class="new-price">New price: <span><?php echo e($myProds->productPrice); ?> RWF (5%)</span></p>
        </div>

        <div class="product-detail">
            <h2>About this item:</h2>
            <p><?php echo e($myProds->productDescription); ?>.</p>


            
            
            
            

            
        </div>

        <div class="purchase-info">


            <form action="<?php echo e(route('cart/store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="flex justify-center">
                    <?php
                    $cart = Gloudemans\Shoppingcart\Facades\Cart::content()?>
                    <input value="1" min="1" type="number" id="email"
                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                           placeholder="name@flowbite.com">

                    <?php if($cart->where('id',$myProds->id)->count()): ?>
                        <button disabled class="text-blue-600 bg-blue-100 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Added to cart
                        </button>
                    <?php else: ?>
                        <button type="submit"
                                class="text-white bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                            Add to cart
                        </button>
                <?php endif; ?>
            </form>
        </div>


    </div>

    <div class="social-links">
        <p>Share to:</p>
        <a href="#">
            <ion-icon name="logo-facebook"></ion-icon>
        </a>
        <a href="#">
            <ion-icon name="logo-whatsapp"></ion-icon>
        </a>
    </div>
</div>
</div>
</div>
</div>
<div class="container">
    <div class="product-box">

        <!--
- PRODUCT GRID
-->

        <div class="product-main">

            <h2 class="title">Related items</h2>

            <div class="product-grid">

                <div class="showcase">

                    <div class="showcase-banner">

                        <img src="<?php echo e(asset('images/products/jacket-3.jpg')); ?>" alt="Mens Winter Leathers Jackets"
                             width="300" class="product-img default">
                        <img src="<?php echo e(asset('images/products/jacket-3.jpg')); ?>" alt="Mens Winter Leathers Jackets"
                             width="300" class="product-img hover">

                        <p class="showcase-badge">15%</p>

                        <div class="showcase-actions">

                            <button class="btn-action">
                                <ion-icon name="cart"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="eye-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="repeat-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="bag-add-outline"></ion-icon>
                            </button>

                        </div>

                    </div>

                    <div class="showcase-content">

                        <a href="" class="showcase-category">jacket</a>

                        <a href="">
                            <h3 class="showcase-title">Mens Winter Leathers Jackets</h3>
                        </a>

                        <div class="showcase-rating">
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star-outline"></ion-icon>
                            <ion-icon name="star-outline"></ion-icon>
                        </div>

                        <div class="price-box">
                            <p class="price">$48.00</p>
                            <del>$75.00</del>
                            <ion-icon name="cart" style="color: black;"></ion-icon>

                        </div>

                    </div>

                </div>

                <div class="showcase">

                    <div class="showcase-banner">
                        <img src="<?php echo e(asset('images/products/shirt-1.jpg')); ?>" alt="Pure Garment Dyed Cotton Shirt"
                             class="product-img default" width="300">
                        <img src="<?php echo e(asset('images/products/shirt-1.jpg')); ?>" alt="Pure Garment Dyed Cotton Shirt"
                             class="product-img hover" width="300">

                        <p class="showcase-badge angle black">sale</p>

                        <div class="showcase-actions">
                            <button class="btn-action">
                                <ion-icon name="heart-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="eye-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="repeat-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="bag-add-outline"></ion-icon>
                            </button>
                        </div>
                    </div>

                    <div class="showcase-content">
                        <a href="#" class="showcase-category">shirt</a>

                        <h3>
                            <a href="#" class="showcase-title">Pure Garment Dyed Cotton Shirt</a>
                        </h3>

                        <div class="showcase-rating">
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star-outline"></ion-icon>
                            <ion-icon name="star-outline"></ion-icon>
                        </div>

                        <div class="price-box">
                            <p class="price">$45.00</p>
                            <del>$56.00</del>
                        </div>

                    </div>

                </div>

                <div class="showcase">

                    <div class="showcase-banner">
                        <img src="<?php echo e(asset('images/products/shirt-1.jpg')); ?>" alt="MEN Yarn Fleece Full-Zip Jacket"
                             class="product-img default" width="300">
                        <img src="<?php echo e(asset('images/products/shirt-1.jpg')); ?>" alt="MEN Yarn Fleece Full-Zip Jacket"
                             class="product-img hover" width="300">

                        <div class="showcase-actions">
                            <button class="btn-action">
                                <ion-icon name="heart-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="eye-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="repeat-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="bag-add-outline"></ion-icon>
                            </button>
                        </div>
                    </div>

                    <div class="showcase-content">
                        <a href="#" class="showcase-category">Jacket</a>

                        <h3>
                            <a href="#" class="showcase-title">MEN Yarn Fleece Full-Zip Jacket</a>
                        </h3>

                        <div class="showcase-rating">
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star-outline"></ion-icon>
                            <ion-icon name="star-outline"></ion-icon>
                        </div>

                        <div class="price-box">
                            <p class="price">$58.00</p>
                            <del>$65.00</del>
                        </div>

                    </div>

                </div>

                <div class="showcase">

                    <div class="showcase-banner">
                        <img src="<?php echo e(asset('images/products/shirt-1.jpg')); ?>" alt="Black Floral Wrap Midi Skirt"
                             class="product-img default" width="300">
                        <img src="<?php echo e(asset('images/products/shirt-1.jpg')); ?>" alt="Black Floral Wrap Midi Skirt"
                             class="product-img hover" width="300">

                        <p class="showcase-badge angle pink">new</p>

                        <div class="showcase-actions">
                            <button class="btn-action">
                                <ion-icon name="heart-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="eye-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="repeat-outline"></ion-icon>
                            </button>

                            <button class="btn-action">
                                <ion-icon name="bag-add-outline"></ion-icon>
                            </button>
                        </div>
                    </div>

                    <div class="showcase-content">
                        <a href="#" class="showcase-category">skirt</a>

                        <h3>
                            <a href="#" class="showcase-title">Black Floral Wrap Midi Skirt</a>
                        </h3>

                        <div class="showcase-rating">
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                            <ion-icon name="star"></ion-icon>
                        </div>

                        <div class="price-box">
                            <p class="price">$25.00</p>
                            <del>$35.00</del>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</main>

<?php echo $__env->make('inc/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/detail.js')); ?>"></script>
<script src="<?php echo e(asset('js/flowbite.js')); ?>"></script>

<!--
- ionicon link
-->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>


</html>

<?php /**PATH C:\xampp\htdocs\bestshoprwanda\resources\views/livewire/product-details.blade.php ENDPATH**/ ?>