<div class="grid gap-6 mb-8 lg:grid-cols-2 xl:grid-cols-4">
    {{ $slot }}
</div>
