<x-app-layout>
    <x-slot name="header">
        {{ __('Dashboard') }}
    </x-slot>

    @livewire('dash-cards')



</x-app-layout>
